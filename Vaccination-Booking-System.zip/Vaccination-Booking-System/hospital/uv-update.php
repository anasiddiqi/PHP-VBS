<?php
$stu_id = $_POST['id'];
$stu_cname =$_POST ['cname'];
$stu_fname =$_POST ['fname'];
$stu_age = $_POST['age'];
$stu_vname = $_POST['vname'];
$stu_doses = $_POST['doses'];
$stu_vac = $_POST['vac'];



$conn = mysqli_Connect("localhost","root","","vms-project") or die("connection failed");

$sql = "UPDATE `updatevacc` SET `cname`='{$stu_cname}',`fname`='{$stu_fname}',`age`='{$stu_age}',`vname`='{$stu_vname}',`doses`='{$stu_doses}',`vac`='{$stu_vac}' WHERE id = {$stu_id}";

$result = mysqli_query($conn,$sql) or die("not connected");

header("Location: http://localhost/Vaccination-Booking-System/hospital/update-vacc.php");


?>