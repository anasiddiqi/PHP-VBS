<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="admin/style.css">

</head>
<style>

/* header */

.header{
    background-color:rgb(43, 136, 241);
}
h2{
        font-family: sans-serif;
        color: rgb(19, 20, 22);
        font-weight: 800;
        margin:0;
        padding-top:10px;
        margin-left: 25px;   
}
  
h3{
      font-family: sans-serif;
        color: rgb(19, 20, 22);
        font-weight: 800;
        text-align:center;
        margin:0;
        padding:5px;
        padding-top:0;    
}

span{
        color:white;
}

/* header */

/* main-content */

img{
    height:230px;
}

#main-content{
    padding: 25px;
    min-height: 400px;
    background-image:url("baby.jpg");
    background-size:cover;
}
#main-content h2{
    margin: 0 0 10px;
    text-transform: capitalize;
}
#main-content table{
    width: 100%;
    background-color:rgb(62, 149, 248);
    margin: 0 0 20px;
}
#main-content table th{
    color: #fff;
    background-color: #333;
    text-transform: uppercase;
    border-radius: 0px;
    margin-left:10px;
}

#main-content table td a:nth-child(2){
    background-color: #ee503f;
    margin: 0 0 0 5px;

    
}

tbody tr td:hover{
    color:white;
}
.submit{
    background-color:black;
    color:white;
    border-radius: 10px;
}

   /* main-content */

@media (min-width:150px){
    
    .d-sm-inline{
        display:flex !important;
    }
   }

</style>

<body>

 <!-- header-start  -->

    <?php
    session_start();
    if (!isset($_SESSION["name"])) {
        header("Location: http://localhost/Vaccination-Booking-System/admin/login.php");
         }
        ?>

<div class="header">
    <h2>Dashboard<h2>
        <h3><i class="fa-solid fa-user"></i> <?php echo $_SESSION['name']?></h3>
        </div>

 <!-- header-end  -->

    <?php
    include 'admin-sidebar.php';
         
    ?>

  <div class="col py-3">
        
  <!-- form-start -->

  <div id="main-content">
    <h2>Add Hospital</h2>

  <form class="row g-3" action="save.php" method="post">      
  <div class="col-md-6">
    <label for="inputVaccine Name" class="form-label">Hospital Name</label>
    <input type="hidden" class="form-control" name="id"  value=""/>
    <input type="text" class="form-control" name="hname"  value=""/>
  </div>
  <div class="col-md-6">
    <label for="inputDoses" class="form-label">Email</label>
    <input type="text" class="form-control" name="email"  value=""/>
  </div>
  <div class="col-md-6">
    <label for="inputAge" class="form-label">Branch</label>
    <input type="text" class="form-control" name="branch"  value=""/>
  </div>
  <div class="col-md-6">
  <label for="inputAvailable" class="form-label">Address</label>
    <input type="text" class="form-control" name="address"  value=""/>
  </div>
    <input type="submit" class="submit" value="Add"/>
  </div>
</form>


</div>
  <!-- form-end -->
            
        </div>
    </div>
</div>


</body>
</html>