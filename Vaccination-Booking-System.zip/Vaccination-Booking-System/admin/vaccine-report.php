<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="admin/style.css">

</head>
<style>

/* header */

.header{
    background-color:rgb(43, 136, 241);

}

h2{
    font-family: sans-serif;
    color: rgb(19, 20, 22);
    font-weight: 800;
    margin:0;
    padding-top:10px;
    margin-left: 25px;
}

h3{
    font-family: sans-serif;
    color: rgb(19, 20, 22);
    font-weight: 800;
    text-align:center;
    margin:0;
    padding:5px;
    padding-top:0;
}

span{
    color:white;
}

/* header */

/* main-content */

img{
    height:230px;
}

#main-content{
    padding: 25px;
    min-height: 400px;
    background-image:url("baby.jpg");
    background-size:cover;
}

#main-content h2{
    margin: 0 0 10px;
    text-transform: capitalize;
}

#main-content table{
    width: 100%;
    background-color:rgb(62, 149, 248);
    margin: 0 0 20px;
}

#main-content table th{
    color: #fff;
    background-color: #333;
    text-transform: uppercase;
    border-radius: 0px;
    margin-left:10px;
}

#main-content table td a:nth-child(2){
    background-color: #ee503f;
    margin: 0 0 0 5px;

    
}

tbody tr td:hover{
    color:white;
}

.check{
    color:white;
    font-weight:bold;
}

#edit a{
    text-decoration:none;
    color: white;
}

/* main-content */

@media (min-width:150px){
    
    .d-sm-inline{
        display:flex !important;
    }
   }

</style>

<body>

<!-- header-start -->

    <?php
    session_start();
    if (!isset($_SESSION["name"])) {
        header("Location: http://localhost/Vaccination-Booking-System/admin/login.php");
         }
        ?>

<div class="header">
    <h2>Dashboard<h2>
        <h3><i class="fa-solid fa-user"></i> <?php echo $_SESSION['name']?></h3>
        </div>

<!-- header-end -->

        <?php
    include 'admin-sidebar.php';
         
    ?>

  <div class="col py-3">
      
   <!-- main-content-start -->

  <div id="main-content">
        <h2>Vaccination Reports</h2>

<?php

// database connection start
$conn = mysqli_Connect("localhost","root","","vms-project") or die("not connected");
// database connection end
$sql = "SELECT * FROM `vaccinereport`";

$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result)){
   



?>
    <table cell-padding="7px">
        <thead>
            <th>Id</th>
            <th>Child Name</th>
            <th>Father Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Vaccine Name</th>
            <th>Dose 1</th>
            <th>Dose 2</th>
            <th>Dose 3</th>
            <th>Dose 4</th>
            <th></th>

        </thead>
        <tbody>
          <?php
             while($row = mysqli_fetch_assoc($result)){
          ?>
           
             <tr>
                <td><?php echo $row['id'] ; ?></td>
                <td><?php echo $row['cname'] ; ?></td>
                <td><?php echo $row['fname'] ; ?></td>
                <td><?php echo $row['gender'] ; ?></td>
                <td><?php echo $row['age'] ; ?></td>
                <td><?php echo $row['vname'] ; ?></td>
                <td><?php echo $row['d1'] ; ?></td>
                <td><?php echo $row['d2'] ; ?></td>
                <td><?php echo $row['d3'] ; ?></td>
                <td><?php echo $row['d4'] ; ?></td>

                <td id="edit">
                    <button class="btn btn-dark"><a href='vreport-edit.php?id=<?php echo $row['id'] ; ?>'>Edit</a></button>
                    
                </td>

             </tr>

       <?php } ?>

       </tbody>

    </table>

<?php } ?>

    </div>

             <!-- main-content-end -->

        </div>
    </div>
</div>


</body>
</html>