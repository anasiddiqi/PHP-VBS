<?php
$stu_id = $_POST['id'];
$stu_cname =$_POST ['cname'];
$stu_vname =$_POST ['vname'];
$stu_age = $_POST['age'];
$stu_pname = $_POST['pname'];
$stu_address = $_POST['address'];
$stu_message = $_POST['message'];



$conn = mysqli_Connect("localhost","root","","vms-project") or die("connection failed");

$sql = "UPDATE `parentrequest` SET `cname`='{$stu_cname}',`vname`='{$stu_vname}',`age`='{$stu_age}',`pname`='{$stu_pname}',`address`='{$stu_address}',`message`='{$stu_message}' WHERE id = {$stu_id}";

$result = mysqli_query($conn,$sql) or die("not connected");

header("Location: http://localhost/Vaccination-Booking-System/admin/parent-request.php");


?>