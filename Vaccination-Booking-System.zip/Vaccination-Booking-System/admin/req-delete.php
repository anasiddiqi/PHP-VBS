<?php

$stu_id = $_GET['id'];

$conn = mysqli_Connect("localhost","root","","vms-project") or die("not connected");
// database connection end
$sql = "DELETE FROM `parentrequest` WHERE id = {$stu_id}";

$result= mysqli_query($conn,$sql);

header("Location: http://localhost/Vaccination-Booking-System/admin/parent-request.php");



?>