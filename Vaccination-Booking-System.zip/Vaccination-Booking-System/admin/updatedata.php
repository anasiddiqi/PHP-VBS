<?php
$stu_id = $_POST['id'];
$stu_name =$_POST ['vname'];
$stu_doses = $_POST['doses'];
$stu_age = $_POST['age'];
$stu_mini = $_POST['minimum'];
$stu_avail = $_POST['available'];


$conn = mysqli_Connect("localhost","root","","vms-project") or die("connection failed");

$sql = "UPDATE `listofvaccine` SET `vname`='{$stu_name}',`doses`='{$stu_doses}',`age`='{$stu_age}',`minimum`='{$stu_mini}',`available`='{$stu_avail}' WHERE id = {$stu_id}";

$result = mysqli_query($conn,$sql) or die("not connected");

header("Location: http://localhost/Vaccination-Booking-System/admin/list-vaccine.php");


?>