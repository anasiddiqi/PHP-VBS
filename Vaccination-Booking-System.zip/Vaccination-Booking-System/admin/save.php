<?php

$stu_hname =$_POST ['hname'];
$stu_email =$_POST ['email'];
$stu_branch = $_POST['branch'];
$stu_address = $_POST['address'];



$conn = mysqli_Connect("localhost","root","","vms-project") or die("connection failed");

$sql = "INSERT INTO `listofhospital`(`hname`, `email`, `branch`, `address`) VALUES ('{$stu_hname}','{$stu_email}','{$stu_branch}','{$stu_address}')";

$result = mysqli_query($conn,$sql) or die("not connected");

header("Location: http://localhost/Vaccination-Booking-System/admin/list-hospital.php");



?>