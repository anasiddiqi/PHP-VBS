<?php
$stu_id = $_POST['id'];
$stu_cname =$_POST ['cname'];
$stu_fname = $_POST['fname'];
$stu_gender = $_POST['gender'];
$stu_age = $_POST['age'];
$stu_vname = $_POST['vname'];
$stu_d1 = $_POST['d1'];
$stu_d2 = $_POST['d2'];
$stu_d3 = $_POST['d3'];
$stu_d4 = $_POST['d4'];



$conn = mysqli_Connect("localhost","root","","vms-project") or die("connection failed");

$sql = "UPDATE `vaccinereport` SET `cname`='{$stu_cname}',`fname`='{$stu_fname}',`gender`='{$stu_gender}',`age`='{$stu_age}',`vname`='{$stu_vname}',`d1`='{$stu_d1}',`d2`='{$stu_d2}',`d3`='{$stu_d3}',`d4`='{$stu_d4}' WHERE id = {$stu_id}";

$result = mysqli_query($conn,$sql) or die("not connected");

header("Location: http://localhost/Vaccination-Booking-System/admin/vaccine-report.php");


?>