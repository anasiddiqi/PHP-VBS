<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<style>
     h1:hover{
    
    color: rgb(6, 128, 228);
   
  }
  .card:hover{
    border: 2px solid lightblue;
   }
   .card-title:hover{
        color: rgb(6, 128, 228);    
   }
   .icon a:hover{
    
    transform:rotate(45deg);
   }
   @media only screen (min-width:344) {
     #logo{
      font-size:14px;
     }
     #top-head{
      font-size:large;
     }
   }
</style>
<body>
    
<?php
include 'header.php';

?>
    
    <section id="Vaccine-guide">
    <br><h1 id="top-head">Our Services</h1><br>
    <h5 id="top-head">We can change this manual system into e-vaccination system by collecting the info of infants, registered under website so that those who didn’t took vaccination can avail one more opportunity to save the life of their children . By this system a lot of man-hours can be saved and it is efficient too.</h5>
    <br>
    <div class="card mb-3">
    <div class="row g-0">
     <div class="col-md-4">
      <img src="images/baby.jpg" class="img-fluid rounded-start" alt="...">
      <br><br>
      <img src="images/baby-vacc3.jpeg" class="img-fluid rounded-start" alt="...">

     
    </div>
    <div class="col-md-8">
      <div class="card-body">
        
       
      <h4 class="card-title">Explore Our Services: Simplifying Your Health Journey</h4>
      <p class="card-text">Discover how our comprehensive services cater to your healthcare needs, ensuring convenience and peace of mind every step of the way.</p>

      <h6 class="card-title">Effortless Booking:</h6>
      <p class="card-text">Easily schedule and manage vaccination appointments and consultations with our intuitive online platform.</p>

      <h6 class="card-title">Streamlined Scheduling:</h6>
      <p class="card-text">Manage and adjust appointment times seamlessly to fit your busy schedule, ensuring no missed vaccinations.</p>

      <h6 class="card-title">Comprehensive Records:</h6>
      <p class="card-text">Access and manage vaccination records online, providing quick retrieval and peace of mind during healthcare visits.</p>

      <h6 class="card-title">Flexible Rescheduling:</h6>
      <p class="card-text">Adjust appointment times seamlessly to accommodate changes in your schedule, ensuring no missed vaccinations.</p>

      <h6 class="card-title">Secure Online Access:</h6>
      <p class="card-text">Access and manage vaccination records securely online, ensuring quick retrieval and peace of mind during healthcare visits.</p>

      <h6 class="card-title">Your Satisfaction, Our Priority:</h6>
      <p class="card-text">At Vaccination Booking System, we are dedicated to providing exceptional healthcare services tailored to your needs. Our commitment to efficiency and reliability ensures your family receives the best care possible. Experience the convenience of managing vaccinations effortlessly and confidently—because your health deserves the utmost attention.</p>
        

        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
        
      </div> 
  </div>
</div>
</section>
 
  <!-- footer-start -->

  <section class="link">
  <!-- Footer -->
  <footer class="text-center text-blue" >
    <!-- Grid container -->
    <div class="container p-4 pb-0">
      <!-- Section: CTA -->
      <section class="icon">
        <!-- Facebook -->
        <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- Twitter -->
      <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-google"></i
      ></a>

      <!-- Instagram -->
      <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-instagram"></i
      ></a>
      </section>
      <!-- Section: CTA -->
    </div>
    <!-- Grid container -->
    <div class="text-center p-3 text-white" style="background-color: rgb(6, 88, 196);">
    <a class="text-white text-decoration-none" id="redirect" href="http://localhost/Vaccination-Booking-System/our-services.php">Services</a>  
      <a class="text-white text-decoration-none" id="redirect" href="http://localhost/Vaccination-Booking-System/vacc-guide.php">Vaccination</a>
    </div>
    <!-- Copyright -->
    <div class="text-center p-3 text-white" style="background-color: rgb(6, 88, 196);">
      © 2024 Copyright:
      <a class="text-white text-decoration-none" href="http://localhost/Vaccination-Booking-System/index.php">vaccinationbookingsystem.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
</section>


  <!-- footer-end -->



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>