-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 19, 2024 at 09:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vms-project`
--
CREATE DATABASE IF NOT EXISTS `vms-project` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `vms-project`;

-- --------------------------------------------------------

--
-- Table structure for table `addhospital`
--

DROP TABLE IF EXISTS `addhospital`;
CREATE TABLE `addhospital` (
  `id` int(50) NOT NULL,
  `hname` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `branch` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `cnum` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addhospital`
--

INSERT DELAYED IGNORE INTO `addhospital` (`id`, `hname`, `email`, `branch`, `address`, `cnum`) VALUES
(1, 'Liaquat National', 'liquatnational@gmail.com', 'xyz', 'xyz', '03323566857'),
(2, 'Dow Hospital', 'dowhospital@gmail.com', 'xyz', 'xyz', '03002334122'),
(3, 'Baqai Hospital', 'baqai@gmail.com', '2', 'malir', '03366945574');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT DELAYED IGNORE INTO `admin` (`name`, `email`, `pass`, `date`) VALUES
('ali', 'ali@gmail.com', '70c767c26cb3143bad5e660504fd6a76', '2024-06-12'),
('Rida', 'rida@gmail.com', '0defd533d51ed0a10c5c9dbf93ee78a5', '2024-06-12'),
('Zahid', 'zahid@gmail.com', '2cfd4560539f887a5e420412b370b361', '2024-06-12'),
('Zara', 'zara@gmail.com', '8a3363abe792db2d8761d6403605aeb7', '2024-06-14');

-- --------------------------------------------------------

--
-- Table structure for table `bookhospital`
--

DROP TABLE IF EXISTS `bookhospital`;
CREATE TABLE `bookhospital` (
  `id` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL,
  `type` varchar(80) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `hname` varchar(80) NOT NULL,
  `cnum` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookhospital`
--

INSERT DELAYED IGNORE INTO `bookhospital` (`id`, `cname`, `age`, `type`, `pname`, `address`, `hname`, `cnum`) VALUES
(1, '', '2', '{ Vaccination}', 'Fahad Rameez', 'North Nazimabad Karachi', 'Fahad Rameez', '03366945574'),
(2, 'Aizal Rameez', '2', '{ Vaccination}', 'Fahad Rameez', 'North Nazimabad Karachi', 'Fahad Rameez', '03366945574'),
(3, 'Aizal Rameez', '2', '{ Vaccination}', 'Fahad Rameez', 'North Nazimabad Karachi', 'Fahad Rameez', '03366945574'),
(4, 'Aizal Rameez', '2', '{ Vaccination}', 'Fahad Rameez', 'North Nazimabad Karachi', 'Fahad Rameez', '03366945574'),
(5, 'Humna Rizwan', '3', '{ Vaccination}', 'Rizwan Mansoor', 'Gulshan-e-maymar', 'Rizwan Mansoor', '03326565696'),
(6, 'Humna Rizwan', '3', '{ Vaccination}', 'Rizwan Mansoor', 'Gulshan-e-maymar', 'Rizwan Mansoor', '03326565696'),
(7, 'Dua Shah', '2', '{ Vaccination}', 'Khalid Shah', 'Gulshan-e-Iqbal', 'Khalid Shah', '03226958685'),
(8, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(9, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(10, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(11, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(12, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(13, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(14, 'Zahid Iqbal', '3', '{ Vaccination}', 'Iqbal Hasan', 'Johar', 'Iqbal Hasan', '03366945559'),
(22, '', '', '{ }', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `bookingdetails`
--

DROP TABLE IF EXISTS `bookingdetails`;
CREATE TABLE `bookingdetails` (
  `id` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL,
  `type` varchar(50) NOT NULL,
  `appoint` varchar(50) NOT NULL,
  `time` varchar(30) NOT NULL,
  `rec` varchar(30) NOT NULL,
  `hosp` varchar(60) NOT NULL,
  `dname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookingdetails`
--

INSERT DELAYED IGNORE INTO `bookingdetails` (`id`, `cname`, `age`, `type`, `appoint`, `time`, `rec`, `hosp`, `dname`) VALUES
(1, 'Hammad Ali', '3', 'vaccine-appoint', '11-07-24', '2:00 PM', '1005', 'DTP', 'Maria Shahid'),
(2, 'Afan Iqbal', '4', 'vaccine-appoint', '05-07-24', '3:00 PM', '1008', 'PCV', 'Alishba Hayat'),
(3, 'Hamna Bashir', '10 weeks', 'Vaccine-type', '08-07-24', '2:00 PM', '1001', 'Liaquat National Hospital', 'Maria Shahid'),
(4, 'Nazim Hassan', '2', 'Vaccine-type', '11-7-24', '4:00 PM', '1004', 'Jinnah Hospital,Lahore', 'Zeeshan Ali'),
(5, 'Uzair Khan', '6 weeks', 'Vaccine-type', '15-07-24', '1:00 PM', '1002', 'Dow Hospital', 'Alishba Hayat'),
(6, 'Yusra Siddiqui', '1', 'Vaccine-type', '10-07-24', '2:00 PM', '1006', 'Faisal Hospital', 'Maria Shahid'),
(7, 'Abdul Ahad', '2', 'Vaccine-type', '13-7-24', '3:00 PM', '1005', 'Liaquat National Hospital', 'Zeeshan Ali');

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
CREATE TABLE `certificates` (
  `id` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `certificates`
--

INSERT DELAYED IGNORE INTO `certificates` (`id`, `cname`, `age`) VALUES
(1, 'Haniya Amir', '3'),
(2, 'Adnan Shahid', '2'),
(3, 'Hafsa Khalid', '2'),
(4, 'Shan Mehmood', '3');

-- --------------------------------------------------------

--
-- Table structure for table `childdetails`
--

DROP TABLE IF EXISTS `childdetails`;
CREATE TABLE `childdetails` (
  `id` int(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `birthdate` varchar(12) NOT NULL,
  `age` varchar(12) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `country` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `childdetails`
--

INSERT DELAYED IGNORE INTO `childdetails` (`id`, `name`, `birthdate`, `age`, `gender`, `phone`, `country`, `city`, `state`, `address`) VALUES
(1, 'Sidra Shah', '16-04-2019', '4', 'Female', '3225668569', 'Pakistan', 'Karachi', 'Sindh', 'Gulshan-e-maymar'),
(2, 'Haris Ali', '14-02-2021', '2', 'Male', '3224117567', 'Pakistan', 'Lahore', 'Punjab', 'Gulshan-e-habib housing society'),
(3, 'Zunaira Hassan', '16-09-2021', '3', 'Female', '3326948756', 'Pakistan', 'Islamabad', 'Punjab', 'Bahria Town '),
(4, 'Fatima Ahmed', '03-10-2019', '4', 'Female', '3226415574', 'Pakistan', 'Lahore', 'Islamabad', 'Park view city'),
(5, 'Rayyan Ali', '09-07-2019', '4', 'Male', '3266495778', 'Pakistan', 'Karachi', 'Sindh', 'North Nazimabad'),
(6, 'Esha Adil', '17-05-2020', '3', 'Female', '3327419658', 'Pakistan', 'Lahore', 'Punjab', 'Blue Town Sapphire'),
(7, 'Subhan Khan', '2024', '6 weeks', 'Male', '03452331165', 'Pakistan', 'Islamabad', 'Punjab', 'Bharia Town'),
(8, 'Maria Shah', '2024', '6 weeks', 'Female', '05891124644', 'Pakistan', 'Hyderabad', 'Sindh', 'Johar'),
(9, 'Hiba Faisal', '2024', '6 weeks', 'Female', '03234889572', 'Pakistan', 'Karachi', 'Sindh', 'Johar'),
(10, 'Abdul Rafay', '2023', '3', 'Male', '03334228791', 'Pakistan', 'Faislabad', 'Punjab', 'Green Valley'),
(11, 'Ayat Khan', '2022', '2', 'Female', '02235876947', 'Pakistan', 'Faislabad', 'Punjab', 'Millat Town'),
(12, 'Hasan Ali', '2022', '2', 'Male', '03223774891', 'Pakistan', 'Karachi', 'Sindh', 'Allied Society');

-- --------------------------------------------------------

--
-- Table structure for table `dateofvaccine`
--

DROP TABLE IF EXISTS `dateofvaccine`;
CREATE TABLE `dateofvaccine` (
  `id` int(50) NOT NULL,
  `vacname` varchar(50) NOT NULL,
  `doses` int(5) NOT NULL,
  `age` varchar(15) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `appoint` varchar(30) NOT NULL,
  `drname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dateofvaccine`
--

INSERT DELAYED IGNORE INTO `dateofvaccine` (`id`, `vacname`, `doses`, `age`, `cname`, `appoint`, `drname`) VALUES
(1, 'BCG', 1, 'Birth', 'Aqsa Khalid', '02-07-24', 'Zeeshan Ali'),
(2, 'HepBb', 2, '6 weeks', 'Subhan Khan', '08-07-24', 'Maria Shahid'),
(3, 'DTP', 2, '6 weeks', 'Aiman Ali', '05-07-24', 'Maria Shahid'),
(4, 'DTP', 3, '10 weeks', 'Zaira Ahmed', '11-07-24', 'Danish Khan'),
(5, 'PCV', 3, '10 weeks', 'Maria Shah', '04-07-24', 'Zeeshan Ali'),
(6, 'Hib', 2, '6 weeks', 'Hiba Faisal', '02-07-24', 'Alishba Hayat'),
(7, 'BCG', 1, 'Birth', 'Kinza Haseeb', '05-07-24', 'Maria Shahid'),
(8, 'DTP', 3, '6 weeks', 'Ali Kamran', '11-07-24', 'Alishba Hayat'),
(9, 'BCG', 1, 'Birth', 'Arisha Khan', '28-6-24', 'Zeeshan Ali'),
(10, 'BCG', 1, 'Birth', 'Bareera Ali', '27-6-24', 'Maria Shahid'),
(11, 'DTP', 2, '6 weeks', 'Irtaza Hasan', '15-7-24', 'Danish Khan'),
(12, 'HepBb', 3, '10 weeks', 'Zoya Ahmed', '18-7-24', 'Danish Khan'),
(13, 'PCV', 3, '14 weeks', 'Zayan Ahmed', '16-7-24', 'Maria Shahid'),
(14, 'PCV', 2, '10 weeks', 'Hashir Siddiqi', '12-3-24', 'Alishba Hayat');

-- --------------------------------------------------------

--
-- Table structure for table `listofhospital`
--

DROP TABLE IF EXISTS `listofhospital`;
CREATE TABLE `listofhospital` (
  `id` int(50) NOT NULL,
  `hname` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `branch` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `listofhospital`
--

INSERT DELAYED IGNORE INTO `listofhospital` (`id`, `hname`, `email`, `branch`, `address`) VALUES
(4, 'Liquat National Hospital', 'liquatnationalhospital@gmail.com', '01', 'National Stadium Road,Karachi'),
(5, 'Saifee Hospital', 'saifeehospital@gmail.com', '01', 'North Nazimabad Karachi'),
(6, 'Dow Hospital', 'dowhospital@gmail.com', '01', 'Mission Road,Delhi Colony,Karachi'),
(7, 'Agha Khan Hospital', 'aghakhanhospital@gmail.com', '01', 'National Stadium Road Karachi'),
(8, 'Jinnah Hospital', 'jinnahhospital@gmail.com', '01', 'Usmani Road,Lahore'),
(9, 'Shifa International Hospital', 'shifahospital@gmail.com', '01', 'Patras Bukhari Road,Islamabad'),
(10, 'Faisal Hospital', 'faisalhospital@gmail.com', '01', 'Peoples Colony,Canal Bank,Faisalabad'),
(11, 'Citi Hospital', 'citihospital@gmail.com', '01', 'Defence Road,Bahria Town,Lahore');

-- --------------------------------------------------------

--
-- Table structure for table `listofvaccine`
--

DROP TABLE IF EXISTS `listofvaccine`;
CREATE TABLE `listofvaccine` (
  `id` int(40) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `doses` int(5) NOT NULL,
  `age` varchar(50) NOT NULL,
  `minimum` varchar(50) NOT NULL,
  `available` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `listofvaccine`
--

INSERT DELAYED IGNORE INTO `listofvaccine` (`id`, `vname`, `doses`, `age`, `minimum`, `available`) VALUES
(1, 'BCG', 2, 'Birth or soon after', 'Not applicable', ''),
(2, 'OPV', 4, 'Birth 6,10,14 weeks', '4 weeks', ''),
(3, 'DTP', 3, '6,10,14 weeks', '4 weeks', 'Not Available'),
(4, 'HepBb', 4, 'Birth 6,10,14 weeks', '4 weeks', 'Available'),
(5, 'Hib', 3, '6,10,14 weeks', '4 weeks', 'Available'),
(6, 'PCV', 3, '6,10,14 weeks', '4 weeks', 'Available'),
(7, 'RVc', 3, '6,10,14 weeks', '4 weeks', 'Not Available'),
(8, 'Measles', 1, '9 months', 'Not applicable', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `parentlogin`
--

DROP TABLE IF EXISTS `parentlogin`;
CREATE TABLE `parentlogin` (
  `name` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parentlogin`
--

INSERT DELAYED IGNORE INTO `parentlogin` (`name`, `email`, `pass`, `date`) VALUES
('Aliyan Ali', 'aliyan@gmail.com', '4563', '2024-06-12'),
('Momina Hassan', 'momina@gmail.com', '7896', '2024-06-12'),
('Rasheed', 'rasheed@gmail.com', '309fee4e541e51de2e41f21bebb342', '2024-06-12'),
('sana', 'sana@gmail.com', '943aa0fcda4ee2901a7de9321663b1', '2024-06-12'),
('Anaya Khan', 'anayakhan@gmail.com', '9963', '2024-06-12'),
('haris', 'haris@gmail.com', '7bccfde7714a1ebadf06c5f4cea752', '2024-06-12'),
('farah', 'farah@gmail.com', '132d6c1408f2492456848667346b54', '2024-06-12'),
('anam', 'anam@gmail.com', '4588e674d3f0faf985047d4c3f13ed', '2024-06-12'),
('fiza', 'fiza@gmail.com', 'fb1378d0b80ae44aae0000a3cff0b9', '2024-06-13'),
('Ahmed', 'ahmed@gmail.com', '38a77aa456fc813af07bb428f2363c', '2024-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `parentrequest`
--

DROP TABLE IF EXISTS `parentrequest`;
CREATE TABLE `parentrequest` (
  `id` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `address` varchar(80) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parentrequest`
--

INSERT DELAYED IGNORE INTO `parentrequest` (`id`, `cname`, `vname`, `age`, `pname`, `address`, `message`) VALUES
(1, 'Zahid ', 'BCG', '1', ' Ahmed', 'North Nazimabad Karachi', 'Can we reschedule due to a planned vacation?'),
(2, 'Eman ', 'PCV', '2', 'Naveed ', 'Bharia Town Karachi', 'Unexpected guest visit. Can we change the date?'),
(4, 'Fatima ', 'PCV', '4', 'Raza ', 'Park view city,lahore', 'Weather concerns. Can we move the appointment?'),
(5, 'Anas ', 'Hib', '6W', 'Asif', 'DHA Islamabad', 'Transportation issues today. Can we reschedule?');

-- --------------------------------------------------------

--
-- Table structure for table `prereport`
--

DROP TABLE IF EXISTS `prereport`;
CREATE TABLE `prereport` (
  `id` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `prevacc` varchar(50) NOT NULL,
  `doses` varchar(10) NOT NULL,
  `predate` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prereport`
--

INSERT DELAYED IGNORE INTO `prereport` (`id`, `cname`, `age`, `pname`, `prevacc`, `doses`, `predate`) VALUES
(1, 'Raza Khan', '1', 'Fiza Khan', 'BCG', '1', '08-02-24'),
(2, 'Khadijah Hashir', '6 weeks', 'Anam Hashir', 'HepBb', '2', '20-05-24'),
(3, ' Abdul hadi ', '10 weeks', 'Farah Asad', 'PCV', '2', '10-02-24'),
(4, 'Abrish Ali', '14 weeks', 'Haris Ali', 'HepBb', '3', '12-12-23'),
(5, 'Subhan Khan', '6 weeks', 'Sohail Khan', 'HepBb', '2', '08-07-24'),
(6, 'Aqsa Khalid', 'Birth', 'Khalid', 'BCG', '1', '02-07-24'),
(7, 'Hiba Faisal', '6 weeks', ' Faisal', 'Hib', '1', '05-06-24'),
(8, 'Ali Kamran', '6 weeks', 'Kamran', 'DTP', '2', '07-06-24'),
(9, 'Abdul Rafay', '3', 'Rafay', 'PCV', '1', '12-05-24'),
(10, 'Zaira Ahmed', '10 weeks', ' Ahmed', 'DTP', '2', '05-06-24');

-- --------------------------------------------------------

--
-- Table structure for table `reqhospital`
--

DROP TABLE IF EXISTS `reqhospital`;
CREATE TABLE `reqhospital` (
  `name` varchar(50) NOT NULL,
  `cnum` varchar(10) NOT NULL,
  `child` varchar(50) NOT NULL,
  `age` varchar(12) NOT NULL,
  `chosp` varchar(50) NOT NULL,
  `nhosp` varchar(50) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reqhospital`
--

INSERT DELAYED IGNORE INTO `reqhospital` (`name`, `cnum`, `child`, `age`, `chosp`, `nhosp`, `reason`, `date`, `time`) VALUES
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `signuphospital`
--

DROP TABLE IF EXISTS `signuphospital`;
CREATE TABLE `signuphospital` (
  `name` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signuphospital`
--

INSERT DELAYED IGNORE INTO `signuphospital` (`name`, `email`, `pass`, `date`) VALUES
('Safi Hospital', 'safihospital@gmail.com', '1074cf6dee6fd3a453ea3fa9d190a430', '2024-06-14');

-- --------------------------------------------------------

--
-- Table structure for table `updatevacc`
--

DROP TABLE IF EXISTS `updatevacc`;
CREATE TABLE `updatevacc` (
  `id` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `doses` varchar(5) NOT NULL,
  `vac` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `updatevacc`
--

INSERT DELAYED IGNORE INTO `updatevacc` (`id`, `cname`, `fname`, `age`, `vname`, `doses`, `vac`) VALUES
(1, 'Zara Junaid', 'Junaid', '6 weeks', 'BCG', '1', 'Completed'),
(2, 'Nimra Shahid', 'Shahid', '2', 'PCV', '3', 'Completed'),
(3, 'Maria Shah', 'Hamza Shah', '10 weeks', 'BCG', '3', 'Uncompleted'),
(4, 'Hiba Faisal', 'Faisal ', '6 weeks', 'Hib', '2', 'Uncompleted'),
(5, 'Ali Kamran', 'Kamran', '6 weeks', 'DTP', '3', 'Uncompleted'),
(6, 'Irtaza Hasan', 'Hasan', '6 weeks', 'DTP', '1', 'Completed'),
(7, 'Neha Khalid', 'Khalid', '10 weeks', 'DTP', '2', 'Completed'),
(8, 'Fatima Ahmed', 'Raza Ahmed', '4', 'PCV', '3', 'Uncompleted'),
(9, 'Hashir Zubair', 'Zubair', '10 weeks', 'PCV', '1', 'Completed'),
(10, 'Zoya Kamran', 'Kamran', '10 weeks', 'HepBb', '2', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `vaccinereport`
--

DROP TABLE IF EXISTS `vaccinereport`;
CREATE TABLE `vaccinereport` (
  `id` int(60) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` varchar(15) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `d1` varchar(30) NOT NULL,
  `d2` varchar(30) NOT NULL,
  `d3` varchar(30) NOT NULL,
  `d4` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccinereport`
--

INSERT DELAYED IGNORE INTO `vaccinereport` (`id`, `cname`, `fname`, `gender`, `age`, `vname`, `d1`, `d2`, `d3`, `d4`) VALUES
(1, 'Sobhan Khan', 'Sohail Khan', 'Male', '6 weeks', 'HepBb', '01-05-24', '08-07-24', 'Coming Soon', 'Coming Soon'),
(2, 'Aqsa Khalid', 'Khalid', 'Female', 'Birth ', 'BCG', '02-07--24', 'Coming Soon', 'Coming Soon', 'Coming Soon'),
(3, 'Maria Shah', 'Hamza Shah', 'Female', '6 weeks', 'BCG', '10-2-24', '5-4-24', '       -', '        -'),
(4, 'Hiba Faisal', 'Faisal ', 'Female', '6 weeks', 'Hib', '5-6-24', 'Coming Soon', 'Coming Soon', '        -'),
(5, 'Ali Kamran', 'Kamran', 'Male', '6 weeks', 'DTP', '04-5-24', '07-6-24', 'Coming Soon', '        -'),
(6, 'Zaira Ahmed', 'Ahmed', 'Female', '10 weeks', 'DTP', '10-5-24', '05-6-24', 'Coming Soon', '        -'),
(7, 'Amna Nasir', 'Nasir', 'Female', '2', 'HepBb', '10-2-24', '15-3-24', '20-5-24', 'Coming Soon'),
(8, 'Fatima Ahmed', 'Raza Ahmed', 'Female', '4', 'PCV', '21-3-24', '10-5-24', 'Coming Soon', '        -'),
(9, 'Abdul Rafay', 'Rafay', 'Male', '3', 'PCV', '12-5-24', 'Coming Soon', 'Coming Soon', '        -'),
(10, 'Ayat', 'Azan Khan', 'Female', '3', 'Hib', '21-4-24', '6-5-24', 'Coming Soon', '         -');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addhospital`
--
ALTER TABLE `addhospital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `bookhospital`
--
ALTER TABLE `bookhospital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingdetails`
--
ALTER TABLE `bookingdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `childdetails`
--
ALTER TABLE `childdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dateofvaccine`
--
ALTER TABLE `dateofvaccine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listofhospital`
--
ALTER TABLE `listofhospital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listofvaccine`
--
ALTER TABLE `listofvaccine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parentrequest`
--
ALTER TABLE `parentrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prereport`
--
ALTER TABLE `prereport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updatevacc`
--
ALTER TABLE `updatevacc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vaccinereport`
--
ALTER TABLE `vaccinereport`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addhospital`
--
ALTER TABLE `addhospital`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bookhospital`
--
ALTER TABLE `bookhospital`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `bookingdetails`
--
ALTER TABLE `bookingdetails`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `childdetails`
--
ALTER TABLE `childdetails`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `dateofvaccine`
--
ALTER TABLE `dateofvaccine`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `listofhospital`
--
ALTER TABLE `listofhospital`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `listofvaccine`
--
ALTER TABLE `listofvaccine`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `parentrequest`
--
ALTER TABLE `parentrequest`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `prereport`
--
ALTER TABLE `prereport`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `updatevacc`
--
ALTER TABLE `updatevacc`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `vaccinereport`
--
ALTER TABLE `vaccinereport`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
