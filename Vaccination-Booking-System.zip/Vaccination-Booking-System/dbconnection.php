<?php 

$localhost = "localhost";
$user = "root";
$password = "";
$database   ="vms-project";

$conn = new mysqli($host, $user, $password, $database);

if ($conn -> connect_error) 
{
	die($conn -> error);
}
else
{
	echo "database connected";
}

?>