<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="admin/style.css">

</head>
<style>

    /* header   */

    .header{
    background-color:rgb(43, 136, 241);

    }

    h2{
        font-family: sans-serif;
        color: rgb(19, 20, 22);
        font-weight: 800;
        margin:0;
        padding-top:10px;
        margin-left: 25px;
    }

    h3{
        font-family: sans-serif;
        color: rgb(19, 20, 22);
        font-weight: 800;
        text-align:center;
        margin:0;
        padding:5px;
        padding-top:0;
    }

    span{
        color:white;
    }
    
    /* header   */

    /* cards */
    
    #hyper{
        text-decoration:none;
    }

    .card:hover{
        border: 2px solid lightblue;
    }

    .card-text:hover{
        color: rgb(6, 128, 228); 
        transition-duration:2s;  
    }

    img{
    height:230px;
    }
    
    /* cards */

@media (min-width:150px){
    
    .d-sm-inline{
        display:flex !important;
    }
   }

</style>

<body>
  
<!-- header-start -->

<div class="header">

    <h2>Dashboard<h2>

    <?php
    session_start();
    if (!isset($_SESSION["name"])) {
        header("Location: http://localhost/Vaccination-Booking-System/parent/login.php");
         }
        ?>
        <h3><i class="fa-solid fa-user"></i> <?php echo $_SESSION['name']?></h3>

        </div>

 <!-- header-end -->

<!-- sidebar-start -->

        <?php
             include 'parent-sidebar.php';
         
        ?>

<!-- sidebar-end -->

<!-- cards-start -->

    <div class="col py-3">
        
		<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card">
    <img src="hospital.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <a href="book-hospital.php" id="hyper"><h5 class="card-title">Book Hospital</h5></a>
        <p class="card-text">Secure your child's vaccination appointment effortlessly at our hospital, ensuring streamlined access to essential healthcare services.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
    <img src="baby.jpg" class="card-img-top" alt="...">
      <div class="card-body">
      <a href="vacc-dates.php" id="hyper"><h5 class="card-title">Vaccination Dates</h5></a>
        <p class="card-text">Keep track of important vaccination dates with our easy-to-use scheduling tool, ensuring timely immunizations for your child.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
    <img src="files.jpg" class="card-img-top" alt="...">
      <div class="card-body">
      <a href="child-details.php" id="hyper"><h5 class="card-title">Chid Details</h5></a>
        <p class="card-text">Easily manage and update your child's details for accurate vaccination records and personalized healthcare.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
    <img src="vaccination-chart1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
      <a href="vacc-report.php" id="hyper"><h5 class="card-title">Report Of Vaccine</h5></a>
        <p class="card-text">Access detailed reports of your child's vaccinations easily, ensuring you stay informed about their immunization history.</p>
      </div>
    </div>
  </div>
</div>	

    <!-- cards-end -->

            
        </div>
    </div>
</div>


</body>
</html>