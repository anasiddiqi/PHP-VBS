<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="admin/style.css">

</head>
<style>

/* header */

.header{
    background-color:rgb(43, 136, 241);

}

h2{
    font-family: sans-serif;
    color: rgb(19, 20, 22);
    font-weight: 800;
    margin:0;
    padding-top:10px;
    margin-left: 25px;
        
}

h3{
    font-family: sans-serif;
    color: rgb(19, 20, 22);
    font-weight: 800;
    text-align:center;
    margin:0;
    padding:5px;
    padding-top:0;
       

}

span{
    color:white;
}

/* header */

/* main-content */

img{
    height:230px;
}

#main-content{
    padding: 25px;
    min-height: 400px;
    background-color:rgb(78, 150, 233);
    background-size:cover;
}

#main-content h2{
    margin: 0 0 10px;
    text-transform: capitalize;
}

#main-content table{
    width: 100%;
    background-color:rgb(78, 150, 233);
    margin: 0 0 20px;
}

#main-content table th{
    color: #fff;
    background-color: #333;
    text-transform: uppercase;
    border-radius: 0px;
    margin-left:10px;
}

#main-content table td a:nth-child(2){
    background-color: #ee503f;
    margin: 0 0 0 5px;

    
}

tbody tr td:hover{
    color:white;
}

.request{
    background-color:black;
    color:white;
    border-radius: 10px;

}

/* main-content */

@media (min-width:150px){
    
    .d-sm-inline{
        display:flex !important;
    }
   }

</style>

<body>

<!-- header-start -->

    <?php
    session_start();
    if (!isset($_SESSION["name"])) {
        header("Location: http://localhost/Vaccination-Booking-System/parent/login.php");
         }
        ?>
<div class="header">
    <h2>Dashboard<h2>
        <h3><i class="fa-solid fa-user"></i> <?php echo $_SESSION['name']?></h3>
        </div>

<!-- header-end -->

<!-- sidebar-start -->

<?php
     include 'parent-sidebar.php';
         
?>

<!-- sidebar-end -->

  <div class="col py-3">
     
  <!-- main-content-start -->

  <div id="main-content">
        <h2>Request For Hospital</h2>


<?php

if (isset($_POST["submit"])) {
    $name=$_POST['name'];
    $cnum=$_POST['cnum'];
    $child=$_POST['child'];
    $age=$_POST['age'];
    $chosp=$_POST['chosp'];
    $nhosp=$_POST['nhosp'];
    $reason=$_POST['reason'];
    $date=$_POST['date'];
    $time=$_POST['time'];

    
   
     // database connection start
     $conn = mysqli_Connect("localhost","root","","vms-project") or die("not connected");
     // database connection end
     $sql="INSERT INTO `reqhospital`(`name`, `cnum`, `child`, `age`, `chosp`, `nhosp`, `reason`, `date`, `time`) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}')";
   
 if (mysqli_query($conn,$sql)) {
    echo "record inserted succesfully";

    
 }else{
    echo "error: " . $sql . "<br>" . mysqli_error($conn);
 }


}   

?>
    
    <form class="row g-3" action="" method="post">      
  <div class="col-md-6">
    <label for="inputVaccine Name" class="form-label">Parent/Guardian</label>
    <input type="hidden" class="form-control" name="id"  value=""/>
    <input type="text" class="form-control" name="name" placeholder="Name" value=""/>
  </div>
  <div class="col-md-6">
  <label for="inputAvailable" class="form-label">Contact</label>
    <input type="int" class="form-control" name="cnum"  placeholder="03223566565" value=""/>
  </div>
  <div class="col-md-6">
    <label for="inputMinimum interval" class="form-label">Child</label>
    <input type="text" class="form-control" name="child" placeholder="Name" value=""/>
  </div>
  <div class="col-md-6">
    <label for="inputAge" class="form-label">Age</label>
    <input type="int" class="form-control" name="age" placeholder="2/6 weeks" value=""/>
  </div>
  <div class="col-md-6">
    <label for="inputDoses" class="form-label">Current Hospital</label>
    <input type="text" class="form-control" name="chosp"  value=""/>
  </div> 
  <div class="col-6">
  <label for="inputAvailable" class="form-label">New Hospital</label>
    <input type="text" class="form-control" name="nhosp"  value=""/>
  </div>
  <div class="col-md-12">
  <label for="inputAvailable" class="form-label">Reason for Change</label>
    <input type="text" class="form-control" name="reason"  value=""/>
  </div>
  <div class="col-md-6">
  <label for="inputAvailable" class="form-label">Preferred Appointment Date and Time at New Hospital</label>
    <input type="int" class="form-control" name="date" placeholder="Date" value=""/>
  </div>
  <div class="col-md-6">
  <label for="inputAvailable" class="form-label">Time</label>
    <input type="int" class="form-control" name="time" placeholder="1:00 PM" value=""/>
  </div>
    <input type="submit" class="request" name="submit" value="Submit"/>
  </div>
</form>

  <!-- main-content-end -->
            
        </div>
    </div>
</div>


</body>
</html>