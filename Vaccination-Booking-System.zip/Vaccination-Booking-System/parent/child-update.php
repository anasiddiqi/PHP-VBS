<?php
$stu_id = $_POST['id'];
$stu_name =$_POST ['name'];
$stu_birthdate =$_POST ['birthdate'];
$stu_age = $_POST['age'];
$stu_gender = $_POST['gender'];
$stu_phone = $_POST['phone'];
$stu_country = $_POST['country'];
$stu_city = $_POST['city'];
$stu_state = $_POST['state'];
$stu_address = $_POST['address'];


$conn = mysqli_Connect("localhost","root","","vms-project") or die("connection failed");

$sql = "UPDATE `childdetails` SET `name`='{$stu_name}',`birthdate`='{$stu_birthdate}',`age`='{$stu_age}',`gender`='{$stu_gender}',`phone`='{$stu_phone}',`country`='{$stu_country}',`city`='{$stu_city}',`state`='{$stu_state}',`address`='{$stu_address}' WHERE id = {$stu_id}";

$result = mysqli_query($conn,$sql) or die("not connected");

header("Location: http://localhost/Vaccination-Booking-System/parent/child-details.php");


?>