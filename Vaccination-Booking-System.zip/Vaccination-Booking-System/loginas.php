<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<style>
    body{
    background-image:url("images/baby-vacc1.jpg");
    background-size:cover;
    
    }
    .card-title{
        font-size:40px;
        margin-top:40px;
        font-weight:bolder;
        
    }

    .container-login{
        text-align:center;
    }
    .card-group{
        margin-left:200px;
        margin-right:200px;
        margin-top:60px;
       
    }
    .card{
        height:350px;
        background-color:lightblue;
        border-radius:10px;

    }
    i{
        margin-top:60px;
        font-size:160px;
    }

</style>
<body>
    

   <section class="container-login">
   <h1 class="card-title">Login As:</h1>

   <div class="card-group">
  <div class="card">
  <i class="fa-regular fa-calendar-days"></i>
    <div class="card-body">
      <a href="admin/signup.php"><button type="button" class="btn btn-primary" id="learn">Admin</button></a>

      
    </div>
  </div>
  
  <div class="card">
  <i class="fa-regular fa-calendar-check"></i>
    <div class="card-body">
      
<a href="parent/signup.php"><button type="button" class="btn btn-primary" id="learn">Parent</button></a>

    </div>
  </div>
  <div class="card">
  <i class="fa-solid fa-hospital"></i>
    <div class="card-body">
   
    <a href="hospital/signup.php"><button type="button" class="btn btn-primary" id="learn">Hospital</button></a>


    </div>
  </div>
</div><br>

  </section>

  

    </body>
</html>