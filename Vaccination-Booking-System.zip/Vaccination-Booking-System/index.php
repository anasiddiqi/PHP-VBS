<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<style>

   .carousel-caption{
    color: black;
    font-weight:300px;
   }

   .carousel-caption:hover{
     background-color:lightblue;
    border-radius:10px;
     transition-duration:2s;
   }

    h1:hover{
    
      color: rgb(6, 128, 228);
     
    }

   #pic{
    height:300px;
  
  }

  .label{
    font-weight:bold;
  }

   .card-title:hover{
        color: rgb(6, 128, 228);    
   }

   .icon a:hover{
    
    transform:rotate(45deg);
   }

   .card:hover{
    border: 2px solid lightblue;
   }

  @media (min-width:300px) {
    .d-md-block{
        display:block !important;
    }
}

@media only screen (min-width:344px) {
    #logo{
      font-size:14px;
    }
}

</style>

<body>
    
<?php

include 'header.php';


?>

  <!-- carousel-start -->

  <div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/baby-vacc1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="label">Efficient Child Vaccination Booking System </h5>
        <p class="label-con">Streamline your child's vaccination schedule with our user-friendly booking system. Register today for hassle-free tracking, timely reminders, and comprehensive immunization records. Keep your child safe and protected with ease!</p>
       
       <a href="loginas.php"><button class="btn btn-primary">Register/Login</button></a>
      </div>
    </div>
    
   
  </div>
  
</div>

  <!-- carousel-end -->


  <!-- services-section-start -->

  <section id="services">
    <br><h1 id="top-head">Our Services</h1><br>
    <h5 id="top-head">Our user-friendly platform makes registering your child for vaccinations quick and effortless. Enjoy peace of mind with automated tracking and personalized reminders, ensuring your child never misses an important immunization. Plus, access detailed vaccination records anytime, keeping you informed and confident in your childs health and safety</h5>
    <br>
    <div class="card-group">
  <div class="card">
  <img src="images/schedule.jpg" class="img-fluid rounded-start" id="pic" alt="...">
   
    <div class="card-body">
      <h5 class="card-title">Schedule</h5>
      <p class="card-text">Take charge of your child's health journey with our convenient scheduling system designed for busy parents. Stay informed and proactive with personalized reminders, ensuring every vaccination is scheduled promptly and seamlessly integrated into your family's routine for peace of mind.</p>
    </div>
  </div>
  <div class="card">
  <img src="images/book-appointnment.webp" class="img-fluid rounded-start" id="pic"  alt="...">
  
    <div class="card-body">
      <h5 class="card-title">Book Appointment</h5>
      <p class="card-text">Easily schedule vaccination appointments with our user-friendly system, tailored to accommodate your busy lifestyle. Receive timely reminders and updates, ensuring your child never misses a crucial immunization.</p>
    </div>
  </div>
  <div class="card">
  <img src="images/tracking.jpg" class="img-fluid rounded-start" id="pic" alt="...">
  
    <div class="card-body">
      <h5 class="card-title">Tracking</h5>
      <p class="card-text">Stay informed with real-time updates on your child's vaccination status through our comprehensive tracking system. Receive personalized alerts to ensure every immunization milestone is met, keeping your child healthy and protected effortlessly.</p>
    </div>
  </div>
</div><br>
<a href="our-services.php"><button type="button" class="btn btn-primary" id="learn">Learn More</button></a>
  </section>
<br><br>
  <!-- services-section-end -->




  <!-- guide-section-start -->

<section id="Vaccine-guide">
<br><h1 id="top-head">Vaccination Guide</h1><br>
<div class="card mb-3">
  <div class="row g-0">
    <div class="col-md-4">
      <br>
      <img src="images/vaccine-guide.jpg" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
      <h4 class="card-title">Vaccination Guide: Ensuring Health and Safety</h4>
        <p class="card-text">Vaccinations are crucial for protecting children and adults alike from preventable diseases. Understanding the importance of vaccines and having access to efficient vaccination management systems can significantly impact public health. Here, we explore the main factors of vaccination and the benefits of an online e-vaccination management system.</p>
        
        <h5 class="card-title">Main Factors of Vaccination</h5>
        <p class="card-text">Vaccinations work by stimulating the immune system to produce antibodies against specific diseases without causing the disease itself. This preventive measure not only protects vaccinated individuals but also contributes to herd immunity, reducing the spread of diseases within communities. Common vaccines target diseases such as measles, polio, influenza, and hepatitis, among others, preventing severe complications and even death.</p>
        
        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
       <a href="vacc-guide.php"><button type="button" class="btn btn-primary" id="learn">Learn More</button></a> 
      </div> 
  </div>
</div>
</section>
 
  <!-- guide-section-end -->




  <!-- footer-start -->

  <section class="link">
  <!-- Footer -->
  <footer class="text-center text-blue" >
    <!-- Grid container -->
    <div class="container p-4 pb-0">
      <!-- Section: CTA -->
      <section class="icon">
        <!-- Facebook -->
        <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- Twitter -->
      <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-google"></i
      ></a>

      <!-- Instagram -->
      <a
        data-mdb-ripple-init
        class="btn btn-link btn-floating btn-lg text-body m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-instagram"></i
      ></a>
      </section>
      <!-- Section: CTA -->
    </div>
    <!-- Grid container -->
    
    <div class="text-center p-3 text-white" style="background-color: rgb(6, 88, 196);">

      <a class="text-white text-decoration-none" id="redirect" href="http://localhost/Vaccination-Booking-System/index.php">Home</a>
      <a class="text-white text-decoration-none" id="redirect" href="http://localhost/Vaccination-Booking-System/our-services.php">Services</a>  
      <a class="text-white text-decoration-none" id="redirect" href="http://localhost/Vaccination-Booking-System/vacc-guide.php">Vaccination guide's</a>
      
    </div>
    <!-- Copyright -->
    <div class="text-center p-3 text-white" style="background-color: rgb(6, 88, 196);">
      © 2024 Copyright:
      <a class="text-white text-decoration-none" href="http://localhost/Vaccination-Booking-System/index.php">vaccinationbookingsystem.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
</section>



  <!-- footer-end -->



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>